<?php
/*
---------------------------------------------
Developed by IPAN
Theme by: JANUX (Dennis Ji)
---------------------------------------------
*/
$connection = mysqli_connect('localhost','root','','db_tibsc','3308');
?>